from PIL import Image
import numpy as np

# Cargar la imagen
image_path = "imagen20.jpg"
image = Image.open(image_path)

# Convertir a array de numpy para facilitar la manipulación
image_array = np.array(image)

# Definir las coordenadas de los recortes (aquí tendrás que ajustar manualmente)
# Estas coordenadas son (left, upper, right, lower)
# coords = [
#     (0, 630, 1400, 1730),   # Coordenadas de la primera imagen
#     (0, 2400, 1400, 3405)   # Coordenadas de la segunda imagen
# ]

coords = [
    (100, 830, 2200, 2730),   # Coordenadas de la primera imagen
]

# Recortar y guardar las imágenes individuales
for i, (left, upper, right, lower) in enumerate(coords):
    cropped_image = image.crop((left, upper, right, lower))
    cropped_image.save(f"extracted_image_{i + 1}.png")

print("Extracción completada.")
